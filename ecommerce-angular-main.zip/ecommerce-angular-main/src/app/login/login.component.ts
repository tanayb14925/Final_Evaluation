import { User } from './../modal/Modal';
import { Component, OnInit } from '@angular/core';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  progressBar = false;
  user: User = {} as User;
  username: string;
  password: string;
 // check=false;
  constructor(private userService: UserService) {

  }
  ngOnInit(): void {

  }

  loginUser(username,password) {
    this.progressBar = true;
    this.username=username;
    this.password=password;
    console.log(this.username)
    this.userService.findByUsername(this.username).subscribe(user => {
      this.user = user;
      console.log(user);
      if(user.password==this.password)
      {
      this.userService.saveUsername(user.username);
      window.location.replace("/")
      }
     
    },
    error => {
      console.log(error);
      
    });
  }

}
